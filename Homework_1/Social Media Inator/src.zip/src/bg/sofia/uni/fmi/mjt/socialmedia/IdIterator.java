package bg.sofia.uni.fmi.mjt.socialmedia;

public class IdIterator {
    public static int id = 0;
}
