package bg.sofia.uni.fmi.mjt.socialmedia.content;

public enum ContentType {
    STORY,
    POST
}

